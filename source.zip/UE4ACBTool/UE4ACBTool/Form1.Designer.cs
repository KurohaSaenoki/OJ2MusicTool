﻿
namespace UE4ACBTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ExtractButton = new System.Windows.Forms.Button();
            this.ImportButton = new System.Windows.Forms.Button();
            this.CreateBackupCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // ExtractButton
            // 
            this.ExtractButton.BackColor = System.Drawing.Color.Transparent;
            this.ExtractButton.BackgroundImage = global::UE4ACBTool.Properties.Resources.Button;
            this.ExtractButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ExtractButton.FlatAppearance.BorderSize = 0;
            this.ExtractButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.ExtractButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.ExtractButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExtractButton.Font = new System.Drawing.Font("FTT-SPNewRodin B", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtractButton.ForeColor = System.Drawing.Color.White;
            this.ExtractButton.Location = new System.Drawing.Point(12, 12);
            this.ExtractButton.Name = "ExtractButton";
            this.ExtractButton.Size = new System.Drawing.Size(163, 48);
            this.ExtractButton.TabIndex = 0;
            this.ExtractButton.Text = "Extract ACB";
            this.ExtractButton.UseVisualStyleBackColor = false;
            this.ExtractButton.Click += new System.EventHandler(this.ExtractButton_Click);
            // 
            // ImportButton
            // 
            this.ImportButton.BackColor = System.Drawing.Color.Transparent;
            this.ImportButton.BackgroundImage = global::UE4ACBTool.Properties.Resources.Button;
            this.ImportButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ImportButton.FlatAppearance.BorderSize = 0;
            this.ImportButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.ImportButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.ImportButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ImportButton.Font = new System.Drawing.Font("FTT-SPNewRodin B", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImportButton.ForeColor = System.Drawing.Color.White;
            this.ImportButton.Location = new System.Drawing.Point(194, 12);
            this.ImportButton.Name = "ImportButton";
            this.ImportButton.Size = new System.Drawing.Size(163, 48);
            this.ImportButton.TabIndex = 1;
            this.ImportButton.Text = "Import ACB";
            this.ImportButton.UseVisualStyleBackColor = false;
            this.ImportButton.Click += new System.EventHandler(this.ImportButton_Click);
            // 
            // CreateBackupCheckBox
            // 
            this.CreateBackupCheckBox.AutoSize = true;
            this.CreateBackupCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.CreateBackupCheckBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.CreateBackupCheckBox.FlatAppearance.BorderSize = 0;
            this.CreateBackupCheckBox.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.CreateBackupCheckBox.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.CreateBackupCheckBox.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.CreateBackupCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateBackupCheckBox.Font = new System.Drawing.Font("FTT-SPNewRodin B", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateBackupCheckBox.ForeColor = System.Drawing.Color.White;
            this.CreateBackupCheckBox.Location = new System.Drawing.Point(225, 71);
            this.CreateBackupCheckBox.Name = "CreateBackupCheckBox";
            this.CreateBackupCheckBox.Size = new System.Drawing.Size(114, 13);
            this.CreateBackupCheckBox.TabIndex = 0;
            this.CreateBackupCheckBox.Text = "Create Backups";
            this.CreateBackupCheckBox.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.CreateBackupCheckBox.UseVisualStyleBackColor = false;
            this.CreateBackupCheckBox.CheckedChanged += new System.EventHandler(this.CreateBackupCheckBox_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::UE4ACBTool.Properties.Resources.BG;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(369, 103);
            this.Controls.Add(this.CreateBackupCheckBox);
            this.Controls.Add(this.ImportButton);
            this.Controls.Add(this.ExtractButton);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Unreal Engine 4 ACB Tool";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ExtractButton;
        private System.Windows.Forms.Button ImportButton;
        private System.Windows.Forms.CheckBox CreateBackupCheckBox;
    }
}

