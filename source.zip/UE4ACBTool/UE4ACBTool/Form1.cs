﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UE4ACBTool
{
    public partial class Form1 : Form
	{
		public string StreamingPath = "";
		public string FileName = "";
		public byte[] UAssetFileBytes;
		public byte[] UexpFileBytes;
		public byte[] AcbFileBytes;
		public bool FoundUTFHeader = false;
		public bool FoundAfzBytes = false;
		public bool CancelledDialog = false;
		public int UTFOffset = -1;
		public int UexpFileLength = 0;


		public Form1()
        {
            InitializeComponent();
			if (Properties.Settings.Default.CreateBackups)
			{
				CreateBackupCheckBox.Checked = true;
			}
			else
			{
				CreateBackupCheckBox.Checked = false;
			}
		}

		public void OpenUEFiles()
		{
			//Default all settings whenever doing either option.
			StreamingPath = "";
			FileName = "";
			FoundUTFHeader = false;
			FoundAfzBytes = false;
			CancelledDialog = false;
			UTFOffset = -1;
			UexpFileLength = 0;

			OpenFileDialog OpenDialogStreaming = new OpenFileDialog();
			OpenDialogStreaming.Title = "Open a .uasset";
			OpenDialogStreaming.Filter = "Unreal Engine Game File (*.uasset)|*.uasset|All files (*.*)|*.*";
			if (Properties.Settings.Default.SavedUAssetPath != null)
			{
				OpenDialogStreaming.FileName = Properties.Settings.Default.SavedUAssetPath;
			}
			OpenDialogStreaming.FilterIndex = 1;
			OpenDialogStreaming.CheckFileExists = true;
			OpenDialogStreaming.CheckPathExists = true;
			OpenDialogStreaming.RestoreDirectory = true;
			if (OpenDialogStreaming.ShowDialog() == DialogResult.OK)
			{
				Properties.Settings.Default.SavedUAssetPath = StreamingPath;
				Properties.Settings.Default.Save();

				//Changes the Path from .uasset to .uexp since that's where the .acb is stored.
				StreamingPath = OpenDialogStreaming.FileName;
				StreamingPath = System.IO.Path.ChangeExtension(StreamingPath, "uexp");

				//Gets the .uasset/uexp filenames so when saving the .acb, it knows what to put automatically.
				FileName = Path.GetFileNameWithoutExtension(StreamingPath);

				//If the .uexp doesn't exist after selecting the .uasset, then stop.
				if (File.Exists(StreamingPath) != true)
				{
					MessageBox.Show("ERROR: Cannot find .uexp file to extract from, aborting extraction.");
				}
				//If found, continue
				else
				{
					UexpFileBytes = File.ReadAllBytes(StreamingPath);

					//Find first @UTF to make sure it's actually an .acb file
					for (int x = 0; x < UexpFileBytes.Length - 4; x++)
					{
						if ((char)UexpFileBytes[x] == '@' && (char)UexpFileBytes[x + 1] == 'U' && (char)UexpFileBytes[x + 2] == 'T' && (char)UexpFileBytes[x + 3] == 'F' && FoundUTFHeader == false)
						{
							UTFOffset = x;
							FoundUTFHeader = true;
							break;
						}
					}
					//Find last 4 bytes and determine if they're correct
					for (int x = UexpFileBytes.Length - 4; x < UexpFileBytes.Length; x++)
					{
						if (UexpFileBytes[x] == 0xC1 && UexpFileBytes[x + 1] == 0x83 && UexpFileBytes[x + 2] == 0x2A && UexpFileBytes[x + 3] == 0x9E)
						{
							FoundAfzBytes = true;
							break;
						}
					}
				}
			}
			else
            {
				CancelledDialog = true;
            }
		}

		private void ExtractButton_Click(object sender, EventArgs e)
        {
			OpenUEFiles();

			if(CancelledDialog == false)
            {
				if (FoundUTFHeader == false || FoundAfzBytes == false)
				{
					if (FoundUTFHeader == false)
					{
						MessageBox.Show("ERROR: File did not contain a .acb within it.");
					}
					if (FoundAfzBytes == false)
					{
						MessageBox.Show("ERROR: File did not contain Áƒ*ž at the bottom of the file, did you manually remove these?");
					}
				}
				else
				{
					//Create a new blank file in memory with the length of the uexp, but exclude everything before the @UTF and the final 4 bytes.
					byte[] NewFile = new byte[UexpFileBytes.Length - UTFOffset - 4];

					//Copy every byte after @UTF until last 4 bytes and place it in the blank file.
					long index = 0;
					for (long i = UTFOffset; i < UexpFileBytes.LongLength - 4; i++)
					{
						NewFile[index] = UexpFileBytes[i];
						index++;
					}

					//Save new file as .acb
					SaveFileDialog SaveDialogStreaming = new SaveFileDialog();
					SaveDialogStreaming.Title = "Save As .acb";
					SaveDialogStreaming.FileName = FileName;
					SaveDialogStreaming.Filter = "(*.acb)|*.acb|All files (*.*)|*.*";
					SaveDialogStreaming.CheckPathExists = true;
					SaveDialogStreaming.RestoreDirectory = true;
					if (SaveDialogStreaming.ShowDialog() == DialogResult.OK)
					{
						File.WriteAllBytes(SaveDialogStreaming.FileName, NewFile);
						MessageBox.Show(".acb Successfully Extracted.");
					}
				}
            }
		}

        private void ImportButton_Click(object sender, EventArgs e)
        {
			OpenUEFiles();
			if (CancelledDialog == false)
			{
				if ((FoundUTFHeader == false || FoundAfzBytes == false) && CancelledDialog == false)
				{
					if (FoundUTFHeader == false)
					{
						MessageBox.Show("ERROR: File did not contain a .acb within it.");
					}
					if (FoundAfzBytes == false)
					{
						MessageBox.Show("ERROR: File did not contain Áƒ*ž at the bottom of the file, did you manually remove these?");
					}
				}
				else
				{
					OpenFileDialog OpenDialogStreaming = new OpenFileDialog();
					OpenDialogStreaming.Title = "Open a .acb";
					OpenDialogStreaming.Filter = "Audio Header Package (*.acb)|*.acb|All files (*.*)|*.*";
					if (Properties.Settings.Default.SavedUAssetPath != null)
					{
						OpenDialogStreaming.FileName = Properties.Settings.Default.SavedUAssetPath;
					}
					OpenDialogStreaming.FilterIndex = 1;
					OpenDialogStreaming.CheckFileExists = true;
					OpenDialogStreaming.CheckPathExists = true;
					OpenDialogStreaming.RestoreDirectory = true;
					if (OpenDialogStreaming.ShowDialog() == DialogResult.OK)
					{
						AcbFileBytes = File.ReadAllBytes(OpenDialogStreaming.FileName);

						/////////////UEXP
						//Create a new blank file in memory with the length of the start of the uexp, your new .acb length, and +4 for the final bytes.
						byte[] NewUexpFile = new byte[UTFOffset + AcbFileBytes.Length + 4];

						//Create uexp header
						long index = 0;
						for (long i = 0; i < UTFOffset; i++)
						{
							NewUexpFile[index] = UexpFileBytes[i];
							index++;
						}
						//Insert new .acb
						for (long i = 0; i < AcbFileBytes.Length; i++)
						{
							NewUexpFile[index] = AcbFileBytes[i];
							index++;
						}
						//Add Final 4 Bytes
						NewUexpFile[index] = 0xC1;
						NewUexpFile[index + 1] = 0x83;
						NewUexpFile[index + 2] = 0x2A;
						NewUexpFile[index + 3] = 0x9E;

						//Fix .acb filesize codes in uexp header
						//Get size of the Acb file and convert the lengthsize into bytes
						byte[] AcbLengthBytes = BitConverter.GetBytes(AcbFileBytes.Length);

						//Insert the Acb Length bytes 16 bytes before the @UTF twice to fix the .uexp
						NewUexpFile[UTFOffset - 16] = AcbLengthBytes[0];
						NewUexpFile[UTFOffset - 15] = AcbLengthBytes[1];
						NewUexpFile[UTFOffset - 14] = AcbLengthBytes[2];
						NewUexpFile[UTFOffset - 13] = AcbLengthBytes[3];
						NewUexpFile[UTFOffset - 12] = AcbLengthBytes[0];
						NewUexpFile[UTFOffset - 11] = AcbLengthBytes[1];
						NewUexpFile[UTFOffset - 10] = AcbLengthBytes[2];
						NewUexpFile[UTFOffset - 9] = AcbLengthBytes[3];

						//Get uexp total filesize for modifying the .uasset
						UexpFileLength = NewUexpFile.Length;

						//If CreateBackups is enabled, swap extension to bak and save original file, then swap back for proper saving
						if (CreateBackupCheckBox.Checked)
						{
							File.WriteAllBytes(StreamingPath + ".bak", UexpFileBytes);
						}
						File.WriteAllBytes(StreamingPath, NewUexpFile);

						/////////////UASSET
						StreamingPath = System.IO.Path.ChangeExtension(StreamingPath, "uasset");
						UAssetFileBytes = File.ReadAllBytes(StreamingPath);

						//If CreateBackups is enabled, swap extension to bak and save original file, then swap back for proper saving
						if (CreateBackupCheckBox.Checked)
						{
							File.WriteAllBytes(StreamingPath + ".bak", UAssetFileBytes);
						}

						int FixedCombinedLengths = UexpFileLength + UAssetFileBytes.Length - 4;
						byte[] CombinedLengthBytes = BitConverter.GetBytes(FixedCombinedLengths);

						//Fixes Header Bytes for the UAsset+UExp FileSize Section, not sure how to manually find this if the byte location ever changes through UAssetGUI without having to make checks before importing but that's too much work.
						UAssetFileBytes[169] = CombinedLengthBytes[0];
						UAssetFileBytes[170] = CombinedLengthBytes[1];
						UAssetFileBytes[171] = CombinedLengthBytes[2];
						UAssetFileBytes[172] = CombinedLengthBytes[3];

						//Fixes Final Bytes near the end of the file for the UExp FileSize Section, should be fine if UAssetGUI messes with this since it's on the very bottom and I have it just going back 92 bytes.
						byte[] FixedUExpLengthBytes = BitConverter.GetBytes(UexpFileLength - 4);
						UAssetFileBytes[UAssetFileBytes.Length - 92] = FixedUExpLengthBytes[0];
						UAssetFileBytes[UAssetFileBytes.Length - 91] = FixedUExpLengthBytes[1];
						UAssetFileBytes[UAssetFileBytes.Length - 90] = FixedUExpLengthBytes[2];
						UAssetFileBytes[UAssetFileBytes.Length - 89] = FixedUExpLengthBytes[3];
						File.WriteAllBytes(StreamingPath, UAssetFileBytes);
						MessageBox.Show("Files Successfully Saved.");
					}
				}
			}
		}

        private void CreateBackupCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			Properties.Settings.Default.CreateBackups = !Properties.Settings.Default.CreateBackups;
		}

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
			Properties.Settings.Default.Save();
		}

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
